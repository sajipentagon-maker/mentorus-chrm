<?php
ini_set('log_errors', '0');
ini_set('display_errors', '0');

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array(
        'ok' => false,
        'message' => 'Please submit the form from the page.',
    ));
    exit;
}

require_once __DIR__ . '/class.phpmailer.php';

$mailTo = 'info@mentorus.ae';
$mailFrom = 'info@mentorus.ae';

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$title = trim($_POST['title'] ?? '');
$experience = trim($_POST['experience'] ?? '');

function field($value, $limit)
{
    $value = strip_tags($value);
    if (function_exists('mb_substr')) {
        return mb_substr($value, 0, $limit);
    }
    return substr($value, 0, $limit);
}

$name = field($name, 80);
$email = field($email, 120);
$phone = field($phone, 30);
$title = field($title, 80);
$experience = field($experience, 40);
$digits = preg_replace('/\D+/', '', $phone);

if ($name === '' || !preg_match('/\p{L}/u', $name)) {
    http_response_code(422);
    echo json_encode(array('ok' => false, 'message' => 'Please enter a valid full name.'));
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(array('ok' => false, 'message' => 'Please enter a valid work email.'));
    exit;
}

if (strlen($digits) < 8 || strlen($digits) > 15) {
    http_response_code(422);
    echo json_encode(array('ok' => false, 'message' => 'Please enter a valid phone number.'));
    exit;
}

function cell($value)
{
    return htmlspecialchars($value === '' ? '—' : $value, ENT_QUOTES, 'UTF-8');
}

$body = '<div style="font-family:Arial,sans-serif;font-size:14px;color:#161361;">'
    . '<h2 style="margin:0 0 12px;">CHRM seat request</h2>'
    . '<table cellpadding="8" cellspacing="0" border="0">'
    . '<tr><td><strong>Name</strong></td><td>' . cell($name) . '</td></tr>'
    . '<tr><td><strong>Email</strong></td><td>' . cell($email) . '</td></tr>'
    . '<tr><td><strong>Phone</strong></td><td>' . cell($phone) . '</td></tr>'
    . '<tr><td><strong>Job title</strong></td><td>' . cell($title) . '</td></tr>'
    . '<tr><td><strong>Experience</strong></td><td>' . cell($experience) . '</td></tr>'
    . '</table></div>';

$mail = new PHPMailer();
$mail->isMail();
$mail->CharSet = 'UTF-8';
$mail->isHTML(true);
$mail->setFrom($mailFrom, 'Mentorus CHRM');
$mail->addReplyTo($email, $name);
$mail->addAddress($mailTo);
$mail->Subject = 'CHRM seat request from ' . $name;
$mail->Body = $body;
$mail->AltBody = "Name: $name\nEmail: $email\nPhone: $phone\nJob title: $title\nExperience: $experience";

$sent = false;
try {
    $sent = $mail->send();
} catch (Exception $exception) {
    $sent = false;
}

if (!$sent) {
    http_response_code(500);
    echo json_encode(array(
        'ok' => false,
        'message' => 'We could not send your request. Please WhatsApp or call us instead.',
    ));
    exit;
}

echo json_encode(array(
    'ok' => true,
    'message' => 'Thank you. Your request is in, and our admissions advisor will call you back.',
));
